﻿const present = !!process.env.TELEGRAM_BOT_TOKEN;
console.log(`RUNTIME-ENV: TELEGRAM_BOT_TOKEN present: ${present}`);
