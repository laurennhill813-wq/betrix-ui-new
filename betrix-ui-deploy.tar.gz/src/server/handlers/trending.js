﻿const { sendText } = require("../utils/send");
exports.handle = async (chatId) => {
  await sendText(chatId, \🔧 BETRIX: /trending is active. Full logic coming soon.\);
};
