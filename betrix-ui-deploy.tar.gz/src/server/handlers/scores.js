﻿const { sendText } = require("../utils/send");
exports.handle = async (chatId) => {
  await sendText(chatId, \🔧 BETRIX: /scores is active. Full logic coming soon.\);
};
