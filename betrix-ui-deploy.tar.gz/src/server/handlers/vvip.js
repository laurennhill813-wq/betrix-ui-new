﻿const { sendText } = require("../utils/send");
exports.handle = async (chatId) => {
  await sendText(chatId, \🔧 BETRIX: /vvip is active. Full logic coming soon.\);
};
