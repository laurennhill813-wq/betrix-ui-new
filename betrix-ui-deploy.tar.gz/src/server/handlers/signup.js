﻿const { sendText } = require("../utils/send");
exports.handle = async (chatId) => {
  await sendText(chatId, \🔧 BETRIX: /signup is active. Full logic coming soon.\);
};
