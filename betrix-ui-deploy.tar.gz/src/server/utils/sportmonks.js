﻿const axios = require("axios");
exports.getFixtures = async () => {
  // Placeholder for SportMonks call
  return [{ match: "Chelsea vs Liverpool", time: "18:00" }];
};
