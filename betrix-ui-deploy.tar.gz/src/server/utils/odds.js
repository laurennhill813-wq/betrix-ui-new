﻿const axios = require("axios");
exports.getOdds = async () => {
  // Placeholder for Odds API call
  return [{ match: "Arsenal vs Man City", odds: "2.10" }];
};
